# flet-on-google-idx

Starter files to run a [Flet](https://flet.dev) application on the [Google IDX platform](https://idx.google.com/).

Feel free to fully adapt to your needs!
**ARTICLE: https://ndonkohenri.medium.com/running-packaging-a-flet-app-on-google-idx-60680db6f487**
